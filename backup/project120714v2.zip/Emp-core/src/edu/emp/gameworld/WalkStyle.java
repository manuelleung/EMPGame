package edu.emp.gameworld;

public enum WalkStyle {
	UP,
	LEFT,
	DOWN,
	RIGHT
}
