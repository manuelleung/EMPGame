package edu.emp.gameworld;

public enum CharacterOptions {
	MOVE,
	ATTACK,
	WAIT, 
	NONE
}
