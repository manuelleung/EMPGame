package edu.emp.gameworld;

public enum TurnIndicator {
	PLAYER,
	ENEMY,
	NONE
}
