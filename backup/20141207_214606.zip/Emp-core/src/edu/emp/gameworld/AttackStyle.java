package edu.emp.gameworld;

public enum AttackStyle {
	UP,
	LEFT,
	DOWN,
	RIGHT,
	NONE
}
