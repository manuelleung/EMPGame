package edu.emp.gameworld;

public enum NodeType {
	NONE,
	BLOCKED,
	START,
	END
}
